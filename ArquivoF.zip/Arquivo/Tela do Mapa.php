<!-- Não Finalizada, só siga com o botão -->


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tela do Mapa</title>
    <link href="style.css" rel="stylesheet">
</head>
<body>
<div class="button-31 bg-black" id="btnvoltar">Próximo</div>

<script>
document.getElementById("btnvoltar").addEventListener("click", voltar);

function voltar() {
  window.location.href = "Tela de Selecionar.php";
}
</script>

</body>
</html>