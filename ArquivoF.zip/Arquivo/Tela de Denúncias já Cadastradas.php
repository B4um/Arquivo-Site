<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tela de Denúncias</title>
    <link href="style.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>


  <center>
     <div>
     <div class="button-31 bg-black" id="btnvoltar">Voltar</div>
    <br> 
    <div class="login-box">
    <div class="user-box">
    <label>Número do Protocolo</label>
      <input type="text" name="" required="" disabled="disabled">
    </div>
    <div class="user-box">
    <label>Status</label>
      <input type="text" name="" required="" disabled="disabled">
    </div>
    <div class="user-box">
    <label>Data</label>
      <input type="text" name="" required="" disabled="disabled">
    </div>
    </div>
    </div>
    </center>


<script>
document.getElementById("btnvoltar").addEventListener("click", voltar);

function voltar() {
  window.location.href = "Tela Inicial.php";
}
</script>

</body>
</html>