<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tela de Selecionar Problema</title>
    <link href="style.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<div>
    <center>
    <h1>Selecione um Problema</h1>
    <button class="button-3"><a class="btn" role="button" href="Tela Final.php">Lâmpadas Queimadas</a></button>
    <br><br>
    <button class="button-4"><a class="btn" role="button" href="Tela Final.php">Lâmpadas Acesas ao Dia</a></button>
    <br><br>
    <button class="button-2"><a class="btn" role="button" href="Tela Final.php">Lâmpadas Oscilando</a></button>
    <br><br>
    <button class="button-5"><a class="btn" role="button" href="Tela Final.php">Poste Denificado</a></button>
    </div>
    </center>
</body>
</html>